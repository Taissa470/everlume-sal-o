function mudarRoxoClaro() {
    document.getElementById("unha-desenho").style.backgroundColor = "#eadef7";
}

function mudarRoxoMedio() {
    document.getElementById("unha-desenho").style.backgroundColor = "#8352c9";
}

function mudarRoxoEscuro() {
    document.getElementById("unha-desenho").style.backgroundColor = "#2e1a47";
}

function mostrarDepoimento1() {
    document.getElementById("texto-depoimento").innerHTML = '"Amei o atendimento, minhas unhas ficaram lindas!" - Ana Maria';
}

function mostrarDepoimento2() {
    document.getElementById("texto-depoimento").innerHTML = '"O spa de pés é maravilhoso, saí super relaxada!" - Carla Souza';
}

function salvarAgendamento(event) {
    event.preventDefault();
    
    var nome = document.getElementById("nome-cliente").value;
    var servico = document.getElementById("opcao-servico").value;
    
    alert("Pronto " + nome + "! Seu pedido de " + servico + " foi enviado.");
}
